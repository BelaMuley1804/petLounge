import "./App.css";
import Home from "./Components/Home";
import About from "./Components/About";
import Work from "./Components/Work";
import Testimonial from "./Components/Testimonial";
import Contact from "./Components/Contact";
import Footer from "./Components/Footer";
//import { SidebarData } from './sidebardata';
//import login from "./Components/login";
//import { Route, Routes } from "react-router-dom";
//import { BrowserRouter as Router, Switch } from 'react-router-dom';
//import register from "./Components/register";
//import profile from "./Components/profile";
// import {
//   BrowserRouter as Router,
//   Routes,
//   Route,
// } from "react-router-dom";
function App() {
  return (
    <div className="App">
      <Home />
      <About />
      <Work />
      <Testimonial />
      <Contact />
      <Footer />
       <>
      {/* <Routes>
      
     
          <Route path='/login'  component={login} />
         <Route path='/register' component={register} />
          <Route path='/profile' component={profile} /> 
      
        </Routes> */}
        </> 
    </div>
  
  );
}

export default App;
