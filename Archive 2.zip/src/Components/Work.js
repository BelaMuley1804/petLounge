import React from "react";




const Work = () => {
  const workInfoData = [
    {
      
      title: "Care",
      text: "PetLounge stands at the forefront of pet hospitality, revolutionizing the way pets are cared for in their owners' absence ",
    },
    {
      
      title: "Grooming",
      text: "We give some exceptional features like grooming of your pet ",
    },
    {
     
      title: "Vaccination",
      text: "vaccination skipped!?!?!?!?Don't worry we are here!!",
    },
  ];
  return (
    <div className="work-section-wrapper">
      <div className="work-section-top">
        <p className="primary-subheading">Work</p>
        <h1 className="primary-heading">How It Works</h1>
        <p className="primary-text">
        In an era where pets are cherished members of the family, 
        the need for a reliable and convenient solution for their care during the owners' absence is paramount. PetLounge, a cutting-edge web application,
         addresses this need by providing a comprehensive platform for booking pet accommodations, scheduling pet services, and facilitating secure online payments. 
         The project encompasses a seamless and user-friendly experience for pet owners, ensuring the well-being and happiness of their beloved companions.
        </p>
      </div>
      <div className="work-section-bottom">
        {workInfoData.map((data) => (
          <div className="work-section-info" key={data.title}>
            <div className="info-boxes-img-container">
              <img src={data.image} alt="" />
            </div>
            <h2>{data.title}</h2>
            <p>{data.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Work;
