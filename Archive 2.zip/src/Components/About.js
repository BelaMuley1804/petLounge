import React from "react";
import dog4 from "../Assets/dog4.jpeg"
//import AboutBackgroundImage from "../Assets/about-background-image.png";
import { BsFillPlayCircleFill } from "react-icons/bs";
import AboutBackground from "../Assets/about-background.png";

const About = () => {
  return (
    <div className="about-section-container">
      <div className="about-background-image-container">
        <img src={AboutBackground} alt="" />
      </div>
      <div className="about-section-image-container">
        <img src={dog4} alt="" />
      </div>
      <div className="about-section-text-container">
        <p className="primary-subheading">About</p>
        <h4 className="primary-heading">
          More about us<br></br>
         
        </h4>
        <p className="primary-text">
        PetLounge revolves around the theme of enhancing the pet-owner relationship
         by offering a hassle-free and trustworthy solution for pet care when owners embark on vacations. 
         The application focuses on providing a comfortable staycation or hostel experience for pets, 
         coupled with a range of customizable services to meet each pet's unique needs.
        </p>
        
        <div className="about-buttons-container">
          <button className="secondary-button">Learn More</button>
          <button className="watch-video-button">
            <BsFillPlayCircleFill /> Watch Video
          </button>
        </div>
      </div>
    </div>
  );
};

export default About;
