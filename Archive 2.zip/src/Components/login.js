import React, { useState } from "react";
import { Container, Form, Button } from "react-bootstrap";
//import "bootstrap/dist/css/bootstrap.min.css";
import "./Style.css";
import cat_dog from "../Assets/cat_dog.jpg"
import BannerBackground from "../Assets/home-banner-background.png";
import AboutBackground from "../Assets/about-background.png";

function RegisterPage() {
  const [ownerName, setOwnerName] = useState("");
  const [petName, setPetName] = useState("");
  const [petType, setPetType] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleRegistration = (event) => {
    event.preventDefault();
    if (password !== confirmPassword) {
      alert("Passwords don't match");
      return;
    }
    console.log("Registration successful");
  };

  return (
    <div className="background-common font">
        <div className="home-bannerImage-container">
          <img src={BannerBackground} alt="" />
        </div>
        <div className="about-background-image-container">
        <img src={AboutBackground} alt="" />
      </div>
      <Container className="form-container">
        <h1 className="mt-5 mb-4">Login Page</h1>
        <Form onSubmit={handleRegistration}>
          <Form.Group controlId="ownerName">
            <Form.Label>User Name: </Form.Label>
            <Form.Control
              type="text"
              className="input-bar"
              placeholder="Enter User name"
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
            />
          </Form.Group>

          <Form.Group controlId="petName">
            <Form.Label>Email ID </Form.Label>
            <Form.Control
              type="text"
              className="input-bar"
              placeholder="Enter Your Email ID Here"
              value={petName}
              onChange={(e) => setPetName(e.target.value)}
            />
          </Form.Group>

         

          <Form.Group controlId="password">
            <Form.Label>Password: </Form.Label>
            <Form.Control
              type="password"
              className="input-bar"
              placeholder="Enter password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </Form.Group>

         

          <p className="mt-3">
            Don't have an account?<a href="/register"> Go to register .</a>
          </p>
          <Button variant="primary" type="submit" className="mt-3">
           login
          </Button>
        </Form>
      </Container>
    </div>
  );
}

export default RegisterPage;